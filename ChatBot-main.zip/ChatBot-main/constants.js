const prompts = [
    ["hi","hello"],
    ["who are you", "are you human", "are you bot", "are you human or bot"],
    ["tell me a joke" ],
    ["thank you"],
    ["purpose"],
    ["bye"],
    ["goodmorning"],
    ["goodnight"]
  ]
  
  // Possible responses, in corresponding order
  
  const replies = [  [ "hello "],
  [ "NO I am just a bot"],
  ["i was created by SUGANIDHI in the year of 2023"],
  ["your most welcome sir"],
  ["friendly bot"],
  ["bye take care"],
  ["goodmorning yaar"],
  ["good night yaar"]
  ]
  // Random for any other user input
  
  
  // Whatever else you want :)
  

 
  
